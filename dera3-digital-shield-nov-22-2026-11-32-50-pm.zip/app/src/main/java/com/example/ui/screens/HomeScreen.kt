package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AppBlocking
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Elderly
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Password
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhoneMissed
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.ai.AiAssistantState
import com.example.data.model.AppPreferences
import com.example.data.model.ShieldConfig
import com.example.data.model.ShieldId
import com.example.data.model.UserProfile
import com.example.localization.LocalStrings
import com.example.ui.theme.LocalDera3Colors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    userProfile: UserProfile,
    shieldConfig: ShieldConfig,
    preferences: AppPreferences,
    aiState: AiAssistantState,
    isAdminUser: Boolean,
    isImpersonating: Boolean,
    onExitImpersonation: () -> Unit,
    onOpenAdminPanel: () -> Unit,
    onToggleDarkMode: () -> Unit,
    onToggleLanguage: () -> Unit,
    onSetNotifications: (Boolean) -> Unit,
    onSetSound: (Boolean) -> Unit,
    onSignOut: () -> Unit,
    onToggleCheck: (String, Boolean) -> Unit,
    onSaveEmergencyContact: (String, () -> Unit) -> Unit,
    onTriggerHoneypot: (Boolean) -> Unit,
    onAskAi: (String) -> Unit,
) {
    val strings = LocalStrings.current
    val dera3Colors = LocalDera3Colors.current
    var expandedShieldKey by remember { mutableStateOf<String?>(null) }
    var showSettingsSheet by remember { mutableStateOf(false) }

    val shieldIcons: List<ImageVector> = remember {
        listOf(
            Icons.Filled.Wifi,
            Icons.Filled.Chat,
            Icons.Filled.Email,
            Icons.Filled.VisibilityOff,
            Icons.Filled.Elderly,
            Icons.Filled.Link,
            Icons.Filled.BugReport,
            Icons.Filled.Password,
            Icons.Filled.AppBlocking,
            Icons.Filled.PhoneMissed,
            Icons.Filled.SmartToy,
        )
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                ),
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.Shield,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp),
                        )
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text(
                                text = strings.appName,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                            )
                            Text(
                                text = strings.appTagline,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                },
                actions = {
                    if (isAdminUser && !isImpersonating) {
                        IconButton(
                            onClick = onOpenAdminPanel,
                            modifier = Modifier.testTag("open_admin_button"),
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AdminPanelSettings,
                                contentDescription = strings.adminPanelBtn,
                                tint = MaterialTheme.colorScheme.primary,
                            )
                        }
                    }
                    IconButton(
                        onClick = onToggleLanguage,
                        modifier = Modifier.testTag("home_language_toggle"),
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Language,
                            contentDescription = strings.languageLabel,
                        )
                    }
                    IconButton(
                        onClick = onToggleDarkMode,
                        modifier = Modifier.testTag("home_theme_toggle"),
                    ) {
                        Icon(
                            imageVector = if (preferences.darkMode) Icons.Filled.LightMode else Icons.Filled.DarkMode,
                            contentDescription = if (preferences.darkMode) strings.lightMode else strings.darkMode,
                        )
                    }
                    IconButton(
                        onClick = { showSettingsSheet = true },
                        modifier = Modifier.testTag("home_settings_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Settings,
                            contentDescription = strings.settingsTitle,
                        )
                    }
                },
            )
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter,
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 640.dp),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                if (isImpersonating) {
                    item(key = "impersonation_banner") {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(
                                    text = String.format(strings.viewingAsUserFormat, userProfile.fullName),
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.weight(1f),
                                )
                                Spacer(Modifier.width(8.dp))
                                Button(
                                    onClick = onExitImpersonation,
                                    modifier = Modifier.testTag("exit_impersonation_button"),
                                ) {
                                    Text(strings.returnToAdmin)
                                }
                            }
                        }
                    }
                }

                // Large Red/Crimson Security Score Hero Card
                item(key = "hero_score_card") {
                    val scoreInt = userProfile.securityScore.toInt().coerceIn(0, 100)
                    val animatedProgress by animateFloatAsState(
                        targetValue = scoreInt / 100f,
                        animationSpec = spring(),
                        label = "score_progress",
                    )
                    val advice = when {
                        scoreInt < 40 -> strings.scoreLowAdvice
                        scoreInt < 80 -> strings.scoreMidAdvice
                        else -> strings.scoreHighAdvice
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(24.dp))
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(dera3Colors.heroCardStart, dera3Colors.heroCardEnd)
                                )
                            )
                            .padding(22.dp)
                            .testTag("security_score_card"),
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(
                                    text = strings.securityScoreTitle,
                                    color = Color.White,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                )
                                Surface(
                                    color = Color.White.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(50),
                                ) {
                                    Text(
                                        text = "$scoreInt / 100",
                                        color = Color.White,
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.Bottom) {
                                Text(
                                    text = "$scoreInt",
                                    color = Color.White,
                                    style = MaterialTheme.typography.displaySmall,
                                    fontWeight = FontWeight.Bold,
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    text = strings.securityScoreOutOf,
                                    color = Color.White.copy(alpha = 0.85f),
                                    style = MaterialTheme.typography.titleMedium,
                                    modifier = Modifier.padding(bottom = 4.dp),
                                )
                            }

                            LinearProgressIndicator(
                                progress = { animatedProgress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(10.dp)
                                    .clip(RoundedCornerShape(50)),
                                color = Color.White,
                                trackColor = Color.White.copy(alpha = 0.25f),
                                strokeCap = StrokeCap.Round,
                            )

                            Text(
                                text = advice,
                                color = Color.White.copy(alpha = 0.95f),
                                style = MaterialTheme.typography.bodyMedium,
                            )
                        }
                    }
                }

                // User Name & Email Card right below Score Card
                item(key = "user_identity_card") {
                    Card(
                        modifier = Modifier.fillMaxWidth().testTag("user_info_card"),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Person,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                )
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = userProfile.fullName,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                )
                                Text(
                                    text = userProfile.email,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }

                item(key = "shields_header") {
                    Text(
                        text = strings.allShieldsTitle,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 4.dp),
                    )
                }

                // All 11 Shields Sequentially
                itemsIndexed(
                    items = ShieldId.entries,
                    key = { _, shield -> shield.key },
                ) { idx, shield ->
                    val isDisabled = shieldConfig.disabledShieldIds.contains(shield.key)
                    val isExpanded = expandedShieldKey == shield.key && !isDisabled
                    val title = strings.shieldTitles.getOrElse(idx) { shield.name }
                    val subtitle = strings.shieldSubtitles.getOrElse(idx) { "" }
                    val icon = shieldIcons.getOrElse(idx) { Icons.Filled.Shield }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("shield_card_${shield.key}"),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isDisabled) {
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            } else {
                                MaterialTheme.colorScheme.surface
                            }
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = if (isExpanded) 4.dp else 1.dp),
                    ) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable(enabled = !isDisabled) {
                                        expandedShieldKey = if (isExpanded) null else shield.key
                                    }
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(
                                            if (isDisabled) MaterialTheme.colorScheme.surfaceVariant
                                            else MaterialTheme.colorScheme.primaryContainer
                                        ),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = title,
                                        tint = if (isDisabled) {
                                            MaterialTheme.colorScheme.onSurfaceVariant
                                        } else {
                                            MaterialTheme.colorScheme.primary
                                        },
                                    )
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    ) {
                                        Text(
                                            text = title,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.weight(1f, fill = false),
                                        )
                                        Surface(
                                            color = if (shield == ShieldId.AI_ASSISTANT) {
                                                MaterialTheme.colorScheme.primaryContainer
                                            } else {
                                                dera3Colors.safeContainer
                                            },
                                            shape = RoundedCornerShape(50),
                                        ) {
                                            Text(
                                                text = if (shield == ShieldId.AI_ASSISTANT) {
                                                    strings.onlineAiBadge
                                                } else {
                                                    strings.offlineBadge
                                                },
                                                style = MaterialTheme.typography.labelSmall,
                                                color = if (shield == ShieldId.AI_ASSISTANT) {
                                                    MaterialTheme.colorScheme.primary
                                                } else {
                                                    dera3Colors.safe
                                                },
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                            )
                                        }
                                    }
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        text = if (isDisabled) strings.disabledByAdmin else subtitle,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = if (isDisabled) dera3Colors.danger else MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                if (!isDisabled) {
                                    Icon(
                                        imageVector = if (isExpanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                                        contentDescription = null,
                                    )
                                }
                            }

                            AnimatedVisibility(visible = isExpanded) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(start = 16.dp, end = 16.dp, bottom = 16.dp)
                                ) {
                                    HorizontalDivider(modifier = Modifier.padding(bottom = 12.dp))
                                    when (shield) {
                                        ShieldId.WIFI -> WifiShieldContent(
                                            completedChecks = userProfile.completedChecks,
                                            onToggleCheck = onToggleCheck,
                                        )
                                        ShieldId.WHATSAPP -> WhatsAppShieldContent(
                                            completedChecks = userProfile.completedChecks,
                                            onToggleCheck = onToggleCheck,
                                        )
                                        ShieldId.BREACH -> BreachShieldContent(
                                            completedChecks = userProfile.completedChecks,
                                            onToggleCheck = onToggleCheck,
                                        )
                                        ShieldId.PRIVACY -> PrivacyShieldContent(
                                            completedChecks = userProfile.completedChecks,
                                            onToggleCheck = onToggleCheck,
                                        )
                                        ShieldId.ELDERLY -> ElderlyShieldContent(
                                            savedEmergencyContact = userProfile.emergencyContact,
                                            onSaveEmergencyContact = onSaveEmergencyContact,
                                        )
                                        ShieldId.LINK_SCANNER -> LinkScannerShieldContent(
                                            completedChecks = userProfile.completedChecks,
                                            onScanCompleted = { onToggleCheck("link_scan", true) },
                                        )
                                        ShieldId.HONEYPOT -> HoneypotShieldContent(
                                            completedChecks = userProfile.completedChecks,
                                            honeypotLogs = userProfile.honeypotLogs,
                                            onTriggerHoneypot = onTriggerHoneypot,
                                        )
                                        ShieldId.PASSWORD -> PasswordShieldContent(
                                            completedChecks = userProfile.completedChecks,
                                            onAwardCheck = { checkId -> onToggleCheck(checkId, true) },
                                        )
                                        ShieldId.FAKE_APPS -> FakeAppsShieldContent(
                                            completedChecks = userProfile.completedChecks,
                                            onAwardScan = { onToggleCheck("fake_app_scan", true) },
                                        )
                                        ShieldId.SCAM_CALLS -> ScamCallsShieldContent(
                                            completedChecks = userProfile.completedChecks,
                                            onAwardScan = { onToggleCheck("scam_call_scan", true) },
                                        )
                                        ShieldId.AI_ASSISTANT -> AiAssistantShieldContent(
                                            aiState = aiState,
                                            onAskQuestion = onAskAi,
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                item(key = "bottom_spacer") {
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }

    if (showSettingsSheet) {
        ModalBottomSheet(onDismissRequest = { showSettingsSheet = false }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(
                    text = strings.settingsTitle,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Filled.Notifications, contentDescription = null)
                    Spacer(Modifier.width(12.dp))
                    Text(strings.notificationsLabel, modifier = Modifier.weight(1f))
                    Switch(
                        checked = preferences.notificationsEnabled,
                        onCheckedChange = onSetNotifications,
                        modifier = Modifier.testTag("settings_notifications_switch"),
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Filled.VolumeUp, contentDescription = null)
                    Spacer(Modifier.width(12.dp))
                    Text(strings.soundLabel, modifier = Modifier.weight(1f))
                    Switch(
                        checked = preferences.soundEnabled,
                        onCheckedChange = onSetSound,
                        modifier = Modifier.testTag("settings_sound_switch"),
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        imageVector = if (preferences.darkMode) Icons.Filled.LightMode else Icons.Filled.DarkMode,
                        contentDescription = null,
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(
                        text = if (preferences.darkMode) strings.darkMode else strings.lightMode,
                        modifier = Modifier.weight(1f),
                    )
                    Switch(
                        checked = preferences.darkMode,
                        onCheckedChange = { onToggleDarkMode() },
                        modifier = Modifier.testTag("settings_theme_switch"),
                    )
                }

                FilledTonalButton(
                    onClick = onToggleLanguage,
                    modifier = Modifier.fillMaxWidth().testTag("settings_language_button"),
                ) {
                    Icon(Icons.Filled.Language, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("${strings.languageLabel}: ${strings.switchLanguageBtn}")
                }

                if (!isImpersonating) {
                    Button(
                        onClick = {
                            showSettingsSheet = false
                            onSignOut()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = dera3Colors.danger),
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("settings_sign_out_button"),
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(strings.signOutLabel)
                    }
                }

                Spacer(Modifier.height(12.dp))
            }
        }
    }
}
