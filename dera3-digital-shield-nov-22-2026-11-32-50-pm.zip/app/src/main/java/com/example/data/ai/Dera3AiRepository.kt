package com.example.data.ai

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log
import com.example.localization.AppLanguage
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.content
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout

private const val TAG = "Dera3AiRepo"

sealed interface AiAssistantState {
    data object Idle : AiAssistantState
    data object Loading : AiAssistantState
    data class Streaming(val text: String) : AiAssistantState
    data class Success(val text: String, val isOfflineFallback: Boolean = false) : AiAssistantState
    data class Error(val errorMessage: String, val offlineFallbackText: String) : AiAssistantState
}

class Dera3AiRepository(private val context: Context) {

    private val modelAr by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            systemInstruction = content {
                text(
                    "أنت مساعد الأمن السيبراني الذكي لتطبيق DERA3 (درعك الرقمي). " +
                        "تخاطب المستخدمين غير المتخصصين وكبار السن والأسر باللهجة المصرية البسيطة والواضحة والودودة. " +
                        "أجب دائماً في 5 خطوات عملية مرقمة أو أقل، بدون مصطلحات معقدة، لحماية المستخدم من النصب والاختراق."
                )
            }
        )
    }

    private val modelEn by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            systemInstruction = content {
                text(
                    "You are DERA3 (Your Digital Shield), a friendly cybersecurity assistant for everyday users and seniors. " +
                        "Always reply in 5 clear, actionable numbered steps or fewer, avoiding complex jargon."
                )
            }
        )
    }

    fun isNetworkAvailable(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    fun askStream(question: String, language: AppLanguage): Flow<AiAssistantState> = flow {
        val cleanQuestion = question.trim()
        if (cleanQuestion.isEmpty()) return@flow

        if (!isNetworkAvailable()) {
            emit(
                AiAssistantState.Success(
                    text = offlineAdviceFor(cleanQuestion, language),
                    isOfflineFallback = true
                )
            )
            return@flow
        }

        emit(AiAssistantState.Loading)
        val activeModel = if (language == AppLanguage.AR) modelAr else modelEn
        val accumulated = StringBuilder()

        try {
            withTimeout(60_000L) {
                activeModel.generateContentStream(cleanQuestion).collect { chunk ->
                    val piece = chunk.text.orEmpty()
                    if (piece.isNotEmpty()) {
                        accumulated.append(piece)
                        emit(AiAssistantState.Streaming(accumulated.toString()))
                    }
                }
            }
            if (accumulated.isNotBlank()) {
                emit(AiAssistantState.Success(accumulated.toString(), isOfflineFallback = false))
            } else {
                val msg = if (language == AppLanguage.AR) {
                    "لم يرجع المساعد الذكي إجابة، جرب سؤالاً آخر."
                } else {
                    "The assistant returned an empty response. Please try again."
                }
                emit(AiAssistantState.Error(msg, offlineAdviceFor(cleanQuestion, language)))
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Gemini AI request timed out", e)
            val msg = if (language == AppLanguage.AR) {
                "انتهى وقت الاتصال بالمساعد الذكي (60 ثانية)."
            } else {
                "AI request timed out after 60 seconds."
            }
            emit(AiAssistantState.Error(msg, offlineAdviceFor(cleanQuestion, language)))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Firebase AI Logic request failed", e)
            val msg = e.localizedMessage ?: "AI service error"
            emit(AiAssistantState.Error(msg, offlineAdviceFor(cleanQuestion, language)))
        }
    }

    fun offlineAdviceFor(question: String, language: AppLanguage): String {
        val q = question.lowercase()
        if (language == AppLanguage.EN) {
            return when {
                q.contains("link") || q.contains("url") || q.contains("click") ->
                    "1. Never tap unfamiliar links from SMS or WhatsApp.\n2. Check that the site starts with https:// and has no spelling mistakes.\n3. Avoid shortened links (bit.ly / tinyurl) from unknown senders.\n4. Use Shield 6 (Predictive Link Scanner) in DERA3 before opening."
                q.contains("whatsapp") || q.contains("hack") ->
                    "1. Open WhatsApp -> Linked Devices and remove any unknown device.\n2. Turn on Two-Step Verification with a 6-digit PIN.\n3. Uninstall WhatsApp Gold or any modded app immediately.\n4. Never share your 6-digit SMS activation code."
                q.contains("password") ->
                    "1. Use at least 12 characters with uppercase, lowercase, numbers, and symbols.\n2. Never reuse the same password across email, banking, and social apps.\n3. Use Shield 8 in DERA3 to generate a strong random password."
                q.contains("call") || q.contains("scam") || q.contains("bank") ->
                    "1. Banks NEVER call asking for OTP codes or card PINs.\n2. Hang up immediately if someone pressures you urgently.\n3. Call the official bank number printed on your card.\n4. Block and report the caller in Shield 10."
                q.contains("wifi") || q.contains("wi-fi") ->
                    "1. Avoid banking or entering passwords on free café/airport Wi-Fi.\n2. Forget old open networks on your phone.\n3. Verify the exact network name with staff."
                else ->
                    "1. Never share OTP verification codes with anyone, even if they claim to be bank support.\n2. Avoid unknown links and unofficial APK downloads.\n3. Keep Two-Step Verification enabled on WhatsApp and Email.\n4. Review camera/mic permissions regularly in Settings."
            }
        }

        return when {
            q.contains("لينك") || q.contains("رابط") || q.contains("url") ->
                "١. متفتحش أي لينك غريب جالك في رسالة أو واتساب.\n" +
                    "٢. اتأكد إن الرابط بيبدأ بـ https:// وإن اسم الموقع مكتوب صح من غير غلطات.\n" +
                    "٣. احذر الروابط المختصرة زي bit.ly أو اللي بتوعد بجوائز.\n" +
                    "٤. انسخ اللينك وافحصه الأول في (درع التنبؤ - فحص اللينكات) رقم 6 في التطبيق."

            q.contains("واتس") || q.contains("مخترق") || q.contains("whatsapp") ->
                "١. افتح واتساب فوراً ← الأجهزة المرتبطة، وامسح أي جهاز متعرفوش.\n" +
                    "٢. شغّل التحقق بخطوتين من الإعدادات ← الحساب برقم سري ليك.\n" +
                    "٣. لو عندك واتساب ذهبي أو معدل امسحه ونزل الأصلي من المتجر.\n" +
                    "٤. أوعى تدي كود تفعيل الواتساب (6 أرقام) لأي شخص."

            q.contains("كلمة سر") || q.contains("باسورد") || q.contains("password") ->
                "١. اعمل كلمة سر لا تقل عن 12 حرف فيها حروف كبيرة وصغيرة وأرقام ورموز.\n" +
                    "٢. متستخدمش نفس كلمة السر في الإيميل والبنك والفيسبوك.\n" +
                    "٣. ابعد عن تاريخ ميلادك أو رقم موبايلك في كلمة السر.\n" +
                    "٤. استخدم (درع كلمة السر) رقم 8 لتوليد كلمة سر قوية فوراً."

            q.contains("مكالمة") || q.contains("نصب") || q.contains("بنك") || q.contains("كود") ->
                "١. البنك عمره ما يطلب كود OTP أو رقم الكارت في التليفون.\n" +
                    "٢. لو حد قالك أنا من البنك وطلب كود، اقفل السكة فوراً.\n" +
                    "٣. اتصل إنت بالبنك على الرقم الرسمي المكتوب على ضهر الكارت.\n" +
                    "٤. اعمل حظر وبلاغ للرقم فوراً من (درع مكالمات النصب) رقم 10."

            q.contains("واي فاي") || q.contains("wifi") || q.contains("شبكة") ->
                "١. متدخلش على تطبيق البنك أو تكتب كلمات سر على واي فاي مفتوح في كافيه.\n" +
                    "٢. امسح الشبكات المفتوحة القديمة من إعدادات الواي فاي في موبايلك.\n" +
                    "٣. استخدم بيانات الموبايل لما تعمل أي معاملة مالية مهمة."

            q.contains("كبار") || q.contains("ماما") || q.contains("بابا") || q.contains("تيتة") ->
                "١. احفظ رقم حد من العيلة في (درع كبار السن) للاتصال به قبل أي تصرف.\n" +
                    "٢. ابعت لأهلك رسالة التحذير الجاهزة إن البنك مش بيطلب أكواد في المكالمات."

            else ->
                "١. أوعى تشارك أي كود تفعيل OTP مع أي حد حتى لو قالك من خدمة العملاء.\n" +
                    "٢. متفتحش لينكات جوائز أو عروض وهمية وماتنزلش تطبيقات من بره المتجر.\n" +
                    "٣. شغّل التحقق بخطوتين على الواتساب والإيميل.\n" +
                    "٤. افحص الدروع الـ 11 في DERA3 لرفع درجة أمانك إلى 100."
        }
    }
}
