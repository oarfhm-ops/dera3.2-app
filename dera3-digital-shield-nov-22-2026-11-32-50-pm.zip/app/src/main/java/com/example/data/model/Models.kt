package com.example.data.model

import androidx.annotation.Keep
import com.example.localization.AppLanguage
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class ShieldId(val key: String, val index: Int, val maxPoints: Int) {
    WIFI("shield_1", 0, 15),
    WHATSAPP("shield_2", 1, 20),
    BREACH("shield_3", 2, 10),
    PRIVACY("shield_4", 3, 15),
    ELDERLY("shield_5", 4, 10),
    LINK_SCANNER("shield_6", 5, 10),
    HONEYPOT("shield_7", 6, 10),
    PASSWORD("shield_8", 7, 10),
    FAKE_APPS("shield_9", 8, 5),
    SCAM_CALLS("shield_10", 9, 5),
    AI_ASSISTANT("shield_11", 10, 5),
}

@Keep
@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val fullName: String = "",
    val email: String = "",
    val phoneNumber: String = "",
    val phoneVerified: Boolean = false,
    val securityScore: Long = 0L,
    val completedChecks: List<String> = emptyList(),
    val emergencyContact: String = "",
    val honeypotLogs: List<String> = emptyList(),
    val passwordMasked: String = "••••••••",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class ShieldConfig(
    @DocumentId val id: String = "",
    val disabledShieldIds: List<String> = emptyList(),
    val updatedBy: String = "",
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

data class AppPreferences(
    val darkMode: Boolean = false,
    val language: AppLanguage = AppLanguage.AR,
    val notificationsEnabled: Boolean = true,
    val soundEnabled: Boolean = true,
)

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}
