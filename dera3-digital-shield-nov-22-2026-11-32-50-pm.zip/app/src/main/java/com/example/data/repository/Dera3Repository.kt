package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.R
import com.example.data.firebase.OperationType
import com.example.data.firebase.handleFirestoreError
import com.example.data.model.ShieldConfig
import com.example.data.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

object ShieldScorePoints {
    val pointsByCheckId: Map<String, Int> = mapOf(
        // Shield 1: Wi-Fi (15 pts)
        "wifi_1" to 5,
        "wifi_2" to 5,
        "wifi_3" to 5,
        // Shield 2: WhatsApp (20 pts)
        "wa_1" to 5,
        "wa_2" to 5,
        "wa_3" to 5,
        "wa_btn" to 5,
        // Shield 3: Data Breach (10 pts)
        "breach_1" to 5,
        "breach_2" to 5,
        // Shield 4: Privacy / Surveillance (15 pts)
        "priv_1" to 5,
        "priv_2" to 5,
        "priv_3" to 5,
        // Shield 5: Elderly (10 pts)
        "elderly_contact" to 10,
        // Shield 6: Link Scanner (10 pts)
        "link_scan" to 10,
        // Shield 7: Honeypot (10 pts)
        "honeypot_active" to 10,
        // Shield 8: Password (10 pts)
        "pw_check" to 5,
        "pw_gen" to 5,
        // Shield 9: Fake Apps (5 pts)
        "fake_app_scan" to 5,
        // Shield 10: Scam Calls (5 pts)
        "scam_call_scan" to 5,
        // Shield 11: AI Assistant (up to 15 pts across first 3 questions)
        "ai_ask_1" to 5,
        "ai_ask_2" to 5,
        "ai_ask_3" to 5,
    )

    fun calculateScore(completedChecks: List<String>): Long {
        val total = completedChecks.distinct().sumOf { pointsByCheckId[it] ?: 5 }
        return total.coerceIn(0, 100).toLong()
    }
}

class Dera3Repository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth,
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in before accessing Firestore.")
    }

    fun observeUserProfile(userId: String): Flow<UserProfile?> {
        if (userId.isBlank()) return flowOf(null)
        val path = "users/$userId"
        return db.collection("users").document(userId)
            .snapshots()
            .map { snapshot ->
                if (snapshot.exists()) {
                    snapshot.toObject(
                        UserProfile::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                } else {
                    null
                }
            }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                if (auth.currentUser != null) {
                    handleFirestoreError(firestoreError ?: error, OperationType.GET, path)
                }
                throw error
            }
    }

    fun observeShieldConfig(): Flow<ShieldConfig> {
        if (auth.currentUser == null) return flowOf(ShieldConfig())
        val path = "app_config/shields"
        return db.collection("app_config").document("shields")
            .snapshots()
            .map { snapshot ->
                if (snapshot.exists()) {
                    snapshot.toObject(
                        ShieldConfig::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ) ?: ShieldConfig()
                } else {
                    ShieldConfig()
                }
            }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                if (auth.currentUser != null) {
                    handleFirestoreError(firestoreError ?: error, OperationType.GET, path)
                }
                // Fallback to default all-enabled config on read error if non-cancellation
                emit(ShieldConfig())
            }
    }

    fun observeAllUsers(): Flow<List<UserProfile>> = flow {
        val currentEmail = auth.currentUser?.email
        if (auth.currentUser == null) {
            emit(emptyList())
            return@flow
        }
        Log.d("Dera3Repo", "Observing all users for admin: $currentEmail")
        val path = "users"
        db.collection("users")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    UserProfile::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                if (auth.currentUser != null) {
                    handleFirestoreError(firestoreError ?: error, OperationType.LIST, path)
                }
                throw error
            }
            .collect { emit(it) }
    }

    suspend fun createUserProfile(
        fullName: String,
        email: String,
        phoneNumber: String,
    ): Result<Unit> {
        val uid = auth.currentUser?.uid ?: "unauthenticated"
        val docPath = "users/$uid"
        return try {
            val activeUid = requireUserId()
            val cleanName = fullName.trim().take(100)
            val cleanEmail = email.trim().take(150)
            val cleanPhone = phoneNumber.trim().take(30)
            require(cleanName.isNotEmpty()) { "Full name is required" }
            require(cleanEmail.length >= 3) { "Valid email is required" }

            val payload = mapOf(
                "userId" to activeUid,
                "fullName" to cleanName,
                "email" to cleanEmail,
                "phoneNumber" to cleanPhone,
                "phoneVerified" to false,
                "securityScore" to 0L,
                "completedChecks" to emptyList<String>(),
                "emergencyContact" to "",
                "honeypotLogs" to emptyList<String>(),
                "passwordMasked" to "••••••••",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
            )
            db.collection("users").document(activeUid).set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun verifyPhoneOtp(userId: String): Result<Unit> {
        val docPath = "users/$userId"
        return try {
            val activeUid = requireUserId()
            check(activeUid == userId) { "User mismatch" }
            db.collection("users").document(userId)
                .update(
                    mapOf(
                        "phoneVerified" to true,
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                )
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun setCheckCompleted(
        userId: String,
        checkId: String,
        completed: Boolean,
    ): Result<Unit> {
        val docPath = "users/$userId"
        return try {
            val activeUid = requireUserId()
            check(activeUid == userId) { "User mismatch" }
            val docRef = db.collection("users").document(userId)
            db.runTransaction { tx ->
                val snap = tx.get(docRef)
                val existing = (snap.get("completedChecks") as? List<*>)
                    ?.filterIsInstance<String>()
                    ?.toMutableList()
                    ?: mutableListOf()
                if (completed) {
                    if (!existing.contains(checkId) && existing.size < 50) {
                        existing.add(checkId)
                    }
                } else {
                    existing.remove(checkId)
                }
                val newScore = ShieldScorePoints.calculateScore(existing)
                tx.update(
                    docRef,
                    mapOf(
                        "completedChecks" to existing,
                        "securityScore" to newScore,
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                )
            }.await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun awardAiQuestionPoint(userId: String): Result<Unit> {
        val docPath = "users/$userId"
        return try {
            val activeUid = requireUserId()
            check(activeUid == userId) { "User mismatch" }
            val docRef = db.collection("users").document(userId)
            db.runTransaction { tx ->
                val snap = tx.get(docRef)
                val existing = (snap.get("completedChecks") as? List<*>)
                    ?.filterIsInstance<String>()
                    ?.toMutableList()
                    ?: mutableListOf()
                val nextSlot = listOf("ai_ask_1", "ai_ask_2", "ai_ask_3").firstOrNull { !existing.contains(it) }
                if (nextSlot != null && existing.size < 50) {
                    existing.add(nextSlot)
                    val newScore = ShieldScorePoints.calculateScore(existing)
                    tx.update(
                        docRef,
                        mapOf(
                            "completedChecks" to existing,
                            "securityScore" to newScore,
                            "updatedAt" to FieldValue.serverTimestamp(),
                        )
                    )
                }
            }.await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun saveEmergencyContact(userId: String, phone: String): Result<Unit> {
        val docPath = "users/$userId"
        return try {
            val activeUid = requireUserId()
            check(activeUid == userId) { "User mismatch" }
            val cleanPhone = phone.trim().take(30)
            require(cleanPhone.isNotEmpty()) { "Emergency phone number cannot be empty" }
            val docRef = db.collection("users").document(userId)
            db.runTransaction { tx ->
                val snap = tx.get(docRef)
                val existing = (snap.get("completedChecks") as? List<*>)
                    ?.filterIsInstance<String>()
                    ?.toMutableList()
                    ?: mutableListOf()
                if (!existing.contains("elderly_contact") && existing.size < 50) {
                    existing.add("elderly_contact")
                }
                val newScore = ShieldScorePoints.calculateScore(existing)
                tx.update(
                    docRef,
                    mapOf(
                        "emergencyContact" to cleanPhone,
                        "completedChecks" to existing,
                        "securityScore" to newScore,
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                )
            }.await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun logHoneypotEvent(userId: String, logEntry: String): Result<Unit> {
        val docPath = "users/$userId"
        return try {
            val activeUid = requireUserId()
            check(activeUid == userId) { "User mismatch" }
            val docRef = db.collection("users").document(userId)
            db.runTransaction { tx ->
                val snap = tx.get(docRef)
                val existingChecks = (snap.get("completedChecks") as? List<*>)
                    ?.filterIsInstance<String>()
                    ?.toMutableList()
                    ?: mutableListOf()
                if (!existingChecks.contains("honeypot_active") && existingChecks.size < 50) {
                    existingChecks.add("honeypot_active")
                }
                val existingLogs = (snap.get("honeypotLogs") as? List<*>)
                    ?.filterIsInstance<String>()
                    ?.toMutableList()
                    ?: mutableListOf()
                existingLogs.add(0, logEntry.take(160))
                val trimmedLogs = existingLogs.take(50)
                val newScore = ShieldScorePoints.calculateScore(existingChecks)
                tx.update(
                    docRef,
                    mapOf(
                        "honeypotLogs" to trimmedLogs,
                        "completedChecks" to existingChecks,
                        "securityScore" to newScore,
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                )
            }.await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun setShieldEnabled(shieldKey: String, enabled: Boolean): Result<Unit> {
        val docPath = "app_config/shields"
        return try {
            val activeUid = requireUserId()
            val docRef = db.collection("app_config").document("shields")
            db.runTransaction { tx ->
                val snap = tx.get(docRef)
                val currentDisabled = if (snap.exists()) {
                    (snap.get("disabledShieldIds") as? List<*>)
                        ?.filterIsInstance<String>()
                        ?.toMutableSet()
                        ?: mutableSetOf()
                } else {
                    mutableSetOf()
                }
                if (enabled) {
                    currentDisabled.remove(shieldKey)
                } else {
                    currentDisabled.add(shieldKey)
                }
                val payload = mapOf(
                    "disabledShieldIds" to currentDisabled.take(11),
                    "updatedBy" to activeUid,
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
                if (snap.exists()) {
                    tx.update(docRef, payload)
                } else {
                    tx.set(docRef, payload)
                }
            }.await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }
}
