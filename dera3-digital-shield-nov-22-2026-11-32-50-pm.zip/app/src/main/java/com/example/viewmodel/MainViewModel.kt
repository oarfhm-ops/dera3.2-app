package com.example.viewmodel

import android.media.AudioManager
import android.media.ToneGenerator
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.AiAssistantState
import com.example.data.ai.Dera3AiRepository
import com.example.data.model.AppPreferences
import com.example.data.model.ShieldConfig
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.data.preferences.PreferencesRepository
import com.example.data.repository.Dera3Repository
import com.example.localization.AppLanguage
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainViewModel(
    private val repository: Dera3Repository,
    private val aiRepository: Dera3AiRepository,
    private val prefsRepository: PreferencesRepository,
    private val currentUserId: String,
    val isAdminUser: Boolean,
) : ViewModel() {

    val preferences: StateFlow<AppPreferences> = prefsRepository.preferencesFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = AppPreferences()
        )

    val userProfileState: StateFlow<UiState<UserProfile?>> = repository.observeUserProfile(currentUserId)
        .map<UserProfile?, UiState<UserProfile?>> { UiState.Success(it) }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(TAG, "Error observing user profile", rootError)
            emit(UiState.Error(rootError.message ?: "Failed to load profile"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = UiState.Loading
        )

    val shieldConfig: StateFlow<ShieldConfig> = repository.observeShieldConfig()
        .catch { error ->
            if (error is CancellationException) throw error
            Log.w(TAG, "Error observing shield config", error)
            emit(ShieldConfig())
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = ShieldConfig()
        )

    val allUsersState: StateFlow<UiState<List<UserProfile>>> = if (isAdminUser) {
        repository.observeAllUsers()
            .map<List<UserProfile>, UiState<List<UserProfile>>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing all users", rootError)
                emit(UiState.Error(rootError.message ?: "Failed to observe users"))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = UiState.Loading
            )
    } else {
        MutableStateFlow(UiState.Success(emptyList()))
    }

    private val _aiState = MutableStateFlow<AiAssistantState>(AiAssistantState.Idle)
    val aiState: StateFlow<AiAssistantState> = _aiState.asStateFlow()

    private val _impersonatingUser = MutableStateFlow<UserProfile?>(null)
    val impersonatingUser: StateFlow<UserProfile?> = _impersonatingUser.asStateFlow()

    private val _actionError = MutableStateFlow<String?>(null)
    val actionError: StateFlow<String?> = _actionError.asStateFlow()

    private val _isSavingAuthStep = MutableStateFlow(false)
    val isSavingAuthStep: StateFlow<Boolean> = _isSavingAuthStep.asStateFlow()

    private var aiJob: Job? = null

    fun toggleDarkMode() {
        viewModelScope.launch {
            prefsRepository.setDarkMode(!preferences.value.darkMode)
        }
    }

    fun toggleLanguage() {
        viewModelScope.launch {
            val next = if (preferences.value.language == AppLanguage.AR) AppLanguage.EN else AppLanguage.AR
            prefsRepository.setLanguage(next)
        }
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        viewModelScope.launch {
            prefsRepository.setNotificationsEnabled(enabled)
        }
    }

    fun setSoundEnabled(enabled: Boolean) {
        viewModelScope.launch {
            prefsRepository.setSoundEnabled(enabled)
        }
    }

    fun clearActionError() {
        _actionError.value = null
    }

    fun createProfile(fullName: String, email: String, phone: String) {
        viewModelScope.launch {
            _isSavingAuthStep.value = true
            val result = repository.createUserProfile(fullName, email, phone)
            _isSavingAuthStep.value = false
            result.onFailure { _actionError.value = it.localizedMessage }
        }
    }

    fun markPhoneVerified() {
        viewModelScope.launch {
            _isSavingAuthStep.value = true
            val result = repository.verifyPhoneOtp(currentUserId)
            _isSavingAuthStep.value = false
            if (result.isSuccess) playFeedbackTone()
            result.onFailure { _actionError.value = it.localizedMessage }
        }
    }

    fun setCheckCompleted(checkId: String, completed: Boolean) {
        if (_impersonatingUser.value != null) return
        viewModelScope.launch {
            val result = repository.setCheckCompleted(currentUserId, checkId, completed)
            if (result.isSuccess && completed) playFeedbackTone()
            result.onFailure { _actionError.value = it.localizedMessage }
        }
    }

    fun saveEmergencyContact(phone: String, onSuccess: () -> Unit) {
        if (_impersonatingUser.value != null) return
        viewModelScope.launch {
            val result = repository.saveEmergencyContact(currentUserId, phone)
            if (result.isSuccess) {
                playFeedbackTone()
                onSuccess()
            } else {
                _actionError.value = result.exceptionOrNull()?.localizedMessage
            }
        }
    }

    fun triggerHoneypot(isSimulation: Boolean) {
        if (_impersonatingUser.value != null) return
        viewModelScope.launch {
            val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            val stamp = fmt.format(Date())
            val entry = if (isSimulation) {
                "[$stamp] Decoy probe intercepted on /admin-login-trap (Blocked)"
            } else {
                "[$stamp] Honeypot shield activated & listening"
            }
            val result = repository.logHoneypotEvent(currentUserId, entry)
            if (result.isSuccess) playFeedbackTone()
            result.onFailure { _actionError.value = it.localizedMessage }
        }
    }

    fun askAiAssistant(question: String) {
        val clean = question.trim()
        if (clean.isEmpty()) return
        aiJob?.cancel()
        aiJob = viewModelScope.launch {
            val lang = preferences.value.language
            aiRepository.askStream(clean, lang).collect { state ->
                _aiState.value = state
                if (state is AiAssistantState.Success && _impersonatingUser.value == null) {
                    repository.awardAiQuestionPoint(currentUserId)
                    playFeedbackTone()
                }
            }
        }
    }

    fun setShieldEnabled(shieldKey: String, enabled: Boolean) {
        if (!isAdminUser) return
        viewModelScope.launch {
            val result = repository.setShieldEnabled(shieldKey, enabled)
            if (result.isSuccess) playFeedbackTone()
            result.onFailure { _actionError.value = it.localizedMessage }
        }
    }

    fun enterAsUser(user: UserProfile) {
        if (!isAdminUser) return
        _impersonatingUser.value = user
    }

    fun exitImpersonation() {
        _impersonatingUser.value = null
    }

    private fun playFeedbackTone() {
        if (!preferences.value.soundEnabled) return
        try {
            val tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 55)
            tone.startTone(ToneGenerator.TONE_PROP_ACK, 110)
        } catch (e: Exception) {
            Log.d(TAG, "Tone playback skipped: ${e.message}")
        }
    }

    private companion object {
        const val TAG = "MainViewModel"
    }
}
