const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";
const ADMIN_UID = "admin_789";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function validUserPayload(uid, email, pastMs = 10000) {
  const ts = new Date(Date.now() - pastMs);
  return {
    userId: uid,
    fullName: "Omar Ahmed",
    email: email,
    phoneNumber: "01012345678",
    phoneVerified: false,
    securityScore: 0,
    completedChecks: [],
    emergencyContact: "",
    honeypotLogs: [],
    passwordMasked: "••••••••",
    createdAt: ts,
    updatedAt: ts,
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read or write users or app_config", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(unauthDb.collection("app_config").doc("shields").get());
  await assertFails(
    unauthDb
      .collection("users")
      .doc(ALICE_UID)
      .set(validUserPayload(ALICE_UID, "alice@example.com"))
  );
});

test("Owner can create profile with score 0 and perform valid partial updates", async () => {
  const aliceDb = testEnv
    .authenticatedContext(ALICE_UID, { email: "alice@example.com", email_verified: true })
    .firestore();

  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .set(validUserPayload(ALICE_UID, "alice@example.com"))
  );

  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .update({
        phoneVerified: true,
        securityScore: 15,
        completedChecks: ["wifi_1", "whatsapp_btn"],
        emergencyContact: "01099998888",
        updatedAt: new Date(Date.now() - 1000),
      })
  );

  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).get());
});

test("Reject score spoofing on create, ghost fields, future timestamps, and immutable createdAt change", async () => {
  const aliceDb = testEnv
    .authenticatedContext(ALICE_UID, { email: "alice@example.com", email_verified: true })
    .firestore();

  // Score must start at 0 on create
  const spoofScore = validUserPayload(ALICE_UID, "alice@example.com");
  spoofScore.securityScore = 100;
  await assertFails(aliceDb.collection("users").doc(ALICE_UID).set(spoofScore));

  // Ghost field 'id' or 'isAdmin' rejected
  const withGhost = validUserPayload(ALICE_UID, "alice@example.com");
  withGhost.id = ALICE_UID;
  await assertFails(aliceDb.collection("users").doc(ALICE_UID).set(withGhost));

  // Future timestamp rejected
  const futureTs = validUserPayload(ALICE_UID, "alice@example.com");
  futureTs.createdAt = new Date(Date.now() + 60000);
  await assertFails(aliceDb.collection("users").doc(ALICE_UID).set(futureTs));

  // Valid create, then reject immutable createdAt mutation
  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .set(validUserPayload(ALICE_UID, "alice@example.com"))
  );
  await assertFails(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .update({
        createdAt: new Date(Date.now() - 500),
        updatedAt: new Date(Date.now() - 500),
      })
  );
});

test("Cross-user isolation: Alice cannot read, list, or update Bob's profile", async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx
      .firestore()
      .collection("users")
      .doc(BOB_UID)
      .set(validUserPayload(BOB_UID, "bob@example.com"));
  });

  const aliceDb = testEnv
    .authenticatedContext(ALICE_UID, { email: "alice@example.com", email_verified: true })
    .firestore();

  await assertFails(aliceDb.collection("users").doc(BOB_UID).get());
  await assertFails(aliceDb.collection("users").get());
  await assertFails(
    aliceDb
      .collection("users")
      .doc(BOB_UID)
      .update({ fullName: "Hacked", updatedAt: new Date(Date.now() - 1000) })
  );
});

test("Admin access & email spoofing protection", async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx
      .firestore()
      .collection("users")
      .doc(ALICE_UID)
      .set(validUserPayload(ALICE_UID, "alice@example.com"));
  });

  // Spoofed unverified admin email MUST fail
  const spoofAdminDb = testEnv
    .authenticatedContext("spoof_uid", {
      email: "oarfhm@gmail.com",
      email_verified: false,
    })
    .firestore();
  await assertFails(spoofAdminDb.collection("users").get());
  await assertFails(
    spoofAdminDb
      .collection("app_config")
      .doc("shields")
      .set({
        disabledShieldIds: ["shield_7"],
        updatedBy: "spoof_uid",
        updatedAt: new Date(Date.now() - 1000),
      })
  );

  // Verified admin email succeeds
  const adminDb = testEnv
    .authenticatedContext(ADMIN_UID, {
      email: "oarfhm@gmail.com",
      email_verified: true,
    })
    .firestore();
  await assertSucceeds(adminDb.collection("users").get());
  await assertSucceeds(
    adminDb
      .collection("app_config")
      .doc("shields")
      .set({
        disabledShieldIds: ["shield_7"],
        updatedBy: ADMIN_UID,
        updatedAt: new Date(Date.now() - 1000),
      })
  );

  // Signed-in regular user can get app_config/shields, cannot write it
  const aliceDb = testEnv
    .authenticatedContext(ALICE_UID, { email: "alice@example.com", email_verified: true })
    .firestore();
  await assertSucceeds(aliceDb.collection("app_config").doc("shields").get());
  await assertFails(
    aliceDb
      .collection("app_config")
      .doc("shields")
      .set({
        disabledShieldIds: [],
        updatedBy: ALICE_UID,
        updatedAt: new Date(Date.now() - 1000),
      })
  );
});
